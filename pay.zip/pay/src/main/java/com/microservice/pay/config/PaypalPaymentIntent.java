package com.microservice.pay.config;

public enum PaypalPaymentIntent {
	sale, authorize, order
}
