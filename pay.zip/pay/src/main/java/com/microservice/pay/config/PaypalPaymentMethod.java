package com.microservice.pay.config;

public enum PaypalPaymentMethod {
	credit_card, paypal
}
